"""
Defines a metaclass Singleton for use in classes which should only be created and initialised once
"""


class Singleton(type):
    """
    Singleton class as metaclass for other classes
    """
    _instance = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instance:
            cls._instance[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instance[cls]

