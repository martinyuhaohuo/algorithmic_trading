import asyncio
import time
from datetime import datetime

import pytz


COMMENT = "#"
NEWLINE = "\n"
UTC_TIMEZONE = 'UTC'
LOCAL_TIMEZONE = "Australia/Melbourne"
DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
DATE_FORMAT_NO_MS = "%Y-%m-%dT%H:%M:%S"

# Some fancy coloured output
C_HEADER = '\033[95m'
C_OKBLUE = '\033[94m'
C_OKLBLUE = '\033[34m'
C_WARNING = '\033[93m'
C_FAIL = '\033[91m'
C_ENDC = '\033[0m'
C_BOLD = '\033[1m'
C_UNDERLINE = '\033[4m'


def time_milli() -> int:
    """
    Current timestamp in milliseconds
    :return: time in milliseconds
    :rtype: int
    """
    return int(round(time.time() * 1000))


def time_milli_formatted() -> str:
    """
    Current timestamp formatted with milliseconds included
    :return: formatted current timestamp
    :rtype: str
    """
    t = time_milli()
    return time.strftime(f"%Y-%m-%dT%H:%M:%S.{t % 1000:0>3}", time.gmtime(t / 1000))


def string_to_date(date_string: str, date_format=DATE_FORMAT, timezone=UTC_TIMEZONE) -> datetime:
    # Python only accepts [0,999999] for %f (microseconds) field
    ds_parts = date_string.split('.')
    ds_parts[-1] = ds_parts[-1][:6]
    date_string = '.'.join(ds_parts)

    localise = pytz.timezone(timezone).localize
    try:
        return localise(datetime.strptime(date_string, date_format))
    except ValueError:
        pass
    try:
        return localise(datetime.strptime(date_string, DATE_FORMAT))
    except ValueError:
        pass
    try:
        return localise(datetime.strptime(date_string, DATE_FORMAT_NO_MS))
    except ValueError:
        raise


def to_local(date: datetime, local_timezone=LOCAL_TIMEZONE) -> datetime:
    timezone = pytz.timezone(local_timezone)
    return date.astimezone(timezone)


def string_to_local_date(date_string: str, remote_timezone=UTC_TIMEZONE) -> datetime:
    return to_local(string_to_date(date_string, timezone=remote_timezone))


def timezone_converter(input_dt: datetime, current_tz=UTC_TIMEZONE, target_tz=LOCAL_TIMEZONE) -> datetime:
    """
    Convert a naive datetime object into timezone aware object
    Current TZ is assumed to be UTC and target TZ is py:data:: LOCAL_TIMEZONE
    """
    current_tz = pytz.timezone(current_tz)
    target_tz = pytz.timezone(target_tz)
    target_dt = current_tz.localize(input_dt).astimezone(target_tz)
    return target_tz.normalize(target_dt)


def clean_line(line):
    line = line.strip()
    if len(line):
        if line[0] == COMMENT:
            return ""
        if line[-1] == NEWLINE:
            return line[:-1]
    return line


def get_index(l: list, item):
    try:
        return l.index(item)
    except ValueError:
        return None


def clean_string(string):
    keepcharacters = ('-', '.', '_', '@')
    return "".join(c for c in string if c.isalnum() or c in keepcharacters).strip()


def str_shorten(string, length=15):
    """Returns a truncated version of string. Default length is 10"""
    return string if len(string) <= length else string[:length]


def str_to_bool(string: str):
    string = string.lower()
    if string == 'true':
        return True
    if string == 'false':
        return False
    raise ValueError(f"Cannot convert {string} to bool")


def parametrise(string, sep='_'):
    return string.replace('-', sep) if isinstance(string, str) else string


def run_or_schedule_coroutine(*coro_or_future):
    # check if a loop exists and call/schedule the coroutines/futures
    if asyncio.get_event_loop().is_running():
        return asyncio.gather(*coro_or_future)
    else:
        return asyncio.get_event_loop().run_until_complete(asyncio.gather(*coro_or_future))
