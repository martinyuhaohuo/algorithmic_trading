from typing import NewType

# New type for email
Email = NewType('Email', str)
