import aiohttp
import platform

from urllib import parse as urlparse


def strip_scheme(url):
    parsed = urlparse.urlparse(url)
    scheme = f"{parsed.scheme}://"
    return parsed.geturl().replace(scheme, '', 1)


def get_ssl_context(default_ssl=True):
    ssl_context = default_ssl
    if platform.system().lower() == 'windows':
        import certifi
        import ssl
        ssl_context = ssl.create_default_context(cafile=certifi.where())
    return ssl_context


def get_fm_connector():
    return aiohttp.TCPConnector(ssl=get_ssl_context())
