"""
This class should contain the initial authorisation that could be passed around for all future communications
"""
from typing import Optional

import aiohttp
import platform

from ...common import utils as net_utils
from ..... import User
from .....utils.constants import API_ROOT
from .....utils.helper import run_or_schedule_coroutine
from .....utils.logging import FMLogger
from .....utils.singleton import Singleton


class Auth(object, metaclass=Singleton):

    auth: aiohttp.BasicAuth
    auth_user: User

    def __init__(self, account=None, email=None, password=None):

        assert account is not None and account != '', "FMAuth: Account cannot be None or empty"
        assert email is not None and email != '', "FMAuth: Email cannot be None or empty"
        assert password is not None and password != '', "FMAuth: Password cannot be None or empty"

        self._email = email
        self._account = account
        self._password = password
        self._username = f"{account}|{email}"
        self._basic_auth = aiohttp.BasicAuth(self._username, self._password)
        self._bearer_auth_header = ''
        self._bearer_token = ''
        self._user = None

        self._logger = FMLogger().get_logger(self.__class__.__name__, 'comms')

        # New bearer auth method requires sending data as POST and getting Bearer token for future auth in header
        async def get_auth_token():
            auth_data = {"username": self._username, "password": self._password}
            auth_url = f"{API_ROOT}/tokens"

            async with aiohttp.ClientSession(connector=net_utils.get_fm_connector(), raise_for_status=True) as sess:
                async with sess.request("POST", auth_url, json=auth_data) as resp:
                    r_j = await resp.json()
                    r_p = r_j.get('person', {})
                    self._logger.debug(f"FM Auth: {r_j}")

                    self._bearer_auth_header = resp.headers.get('Authorization', '')
                    self._basic_auth = self._basic_auth if self._bearer_auth_header else None
                    self._bearer_token = r_j.get('token', None)
                    self._user = User(r_p.get('id', None), r_p)

        run_or_schedule_coroutine(get_auth_token())

    @property
    def auth(self) -> aiohttp.BasicAuth:
        return self._basic_auth

    @property
    def bearer_auth_header(self) -> str:
        return self._bearer_auth_header

    @property
    def bearer_token(self) -> Optional[str]:
        return self._bearer_token

    @property
    def auth_user(self) -> User:
        return self._user
