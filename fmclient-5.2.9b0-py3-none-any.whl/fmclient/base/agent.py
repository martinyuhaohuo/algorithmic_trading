"""
Module consisting of the base class for trading agents.

In order to interact with Flex-e-Markets based servers, base Agent must be sub-classed with concrete implementation
of necessary methods.
"""

import asyncio
import concurrent.futures as ft
import copy
import functools
import logging
import logging.config
import sys
import threading
import traceback
from abc import ABC, abstractmethod
from typing import Dict, List, Union

import coloredlogs
from aiohttp import client_exceptions as aiohttp_exceptions
from blinker import signal

from ..data.message import MessageType
from ..data.orm.holding import Holding
from ..data.orm.market import Market
from ..data.orm.marketplace import Marketplace
from ..data.orm.order import Order
from ..data.orm.session import Session, SessionState
from ..fmio.net.fmapi.rest.auth import Auth as FMAuth
from ..fmio.net.fmapi.rest.request import Request, RequestMethod
from ..fmio.net.fmapi.ws.client import WebSocketClient, IncomingMessageType
from ..fmio.net.hosting.ws.client import AgentWebsocketClient
from ..utils import constants as cons, helper as hlp
from ..utils.constants import FM_HOST, LIB_NAME, LIB_VERSION
from ..utils.logging import FMLogger


# if sys.version_info[0] == 3 and sys.version_info[1] >= 8 and sys.platform.startswith('win'):
#     asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


class Agent(ABC):
    """
    This is the main (abstract) class that will provide the required functionality to build custom trading agents.
    The class provides automatic subscription to order book, holding and marketplace updates.
    In addition, the class also provides websocket communication.
    """

    def __init__(self, account: str, email: str, password: str, marketplace_id: int,
                 name: str = None, enable_ws: bool = False):
        """
        Note: Do not include any method that uses asyncio here. This creates a conflict with upload on AlgoHost.

        :param account: FM account
        :param email:  FM email
        :param password: FM password
        :param marketplace_id: ID of marketplace
        :param name: name of the bot
        :param enable_ws: whether to enable WebSocket communication with AlgoHost
        """
        self._account = account
        self._email = email
        self._password = password
        self._marketplace_id = marketplace_id
        self._name = name if name else email
        self._enable_ws_comm = enable_ws
        self._logger = None
        self._setup_logging()  # This should be init as soon as basic information on an agent is available

        self._loop = None
        self._description = None
        self._stop = False
        self._initialised = False
        self._enable_user_communication = False

        self._initial_data_status = dict(session_update=False, holding_update=False, orders_update=False)
        self._data_signals = dict(session_update=signal('session_update'),
                                  holding_update=signal('holding_update'),
                                  orders_update=signal('orders_update'))
        self._data_init_signal = signal('data-initialised')

        self._incoming_message_queue = None
        self._outgoing_order_queue = None
        self._current_session = None
        self._holdings = None
        self._ws_ah = None
        self._ws_fm = None

        self._monitor_count = 0  # For LAT_TEST ONLY
        self._outgoing_order_count = {}
        self._session_semaphore = threading.Semaphore()  # A semaphore to manage access to session with single access
        self._user_tasks = []

    # ---- SETUP METHODS ----
    def _safely_call_method(self, f: Union[callable, functools.partial]) -> None:
        """
        Wraps and calls a method/function in a try/except block

        :param f: callable to call
        :return: None
        """
        try:
            return f()
        except KeyboardInterrupt:
            raise
        except Exception as ex:
            f_name = f.func.__name__ if isinstance(f, functools.partial) else f.__name__
            e_msg = list(filter(None, [
                f"{ex.__class__.__name__}({str(ex).removesuffix('.')}) in {self.__class__.__name__}.{f_name}() method",
                f"Run with DEBUG for details"]))
            self.error(". ".join(e_msg))
            self.debug(traceback.format_exc())

    def _login(self):
        """
        FMAuth is a singleton and needs to be instantiated before any request is performed.
        #TODO: In case of errors, check if FMAuth was garbage collected.

        :return:
        """
        FMAuth(self._account, self._email, self._password)  # Only need to log in once

    def _init_communication(self):
        if self.enable_user_communication:
            self._send_ws_message("activate communication", msg_type=MessageType.CUSTOM)

    def _setup_logging(self):
        """
        Set up the logger with specific format.

        :return:
        """
        default_config = {
            'agent_name': self._email,
            'marketplace_id': str(self._marketplace_id)
        }

        # Name should be agent.<agent.name> format
        self._logger = FMLogger(default_config=default_config).get_logger(hlp.str_shorten(self.name), "agent")
        try:
            self._log_file = FMLogger().get_logger("agent").handlers[0].baseFilename
        except IndexError:
            self._log_file = ""
        try:
            coloredlogs.DEFAULT_FIELD_STYLES['msecs'] = coloredlogs.DEFAULT_FIELD_STYLES['asctime']
            coloredlogs.DEFAULT_FIELD_STYLES['levelname'] = {'bold': True}  # Removes default color black
            # noinspection PyProtectedMember
            coloredlogs.install(logger=self._logger, milliseconds=True,
                                fmt=FMLogger().get_logger("agent").handlers[0].formatter._fmt)
        except IndexError:
            coloredlogs.install(logger=self._logger, milliseconds=True)

    def _get_event_loop(self):
        """
        If the agent is not running in the main thread, create a new loop and associate it with asyncio.

        :return: Asyncio loop
        """
        if self._loop:
            return self._loop

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError as re:
            loop = None
        if loop is None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop

    def _set_asyncio_properties(self):
        """
        Sets the asyncio properties, e.g., the thread pool executor.

        :return:
        """
        executor = ft.ThreadPoolExecutor(max_workers=cons.ASYNCIO_MAX_THREADS)
        self._loop.set_default_executor(executor)

    # ----- Logging Methods -----
    def inform(self, msg: str, ws: bool = True):
        """
        Send the given message to relevant targets. For example, logging and websocket.

        :param msg: message to log
        :param ws: True will send message on websockets as well
        :return:
        """
        self._logger.info(msg)
        self._send_ws_message(msg, MessageType.INFO) if ws and self._logger.isEnabledFor(logging.INFO) else None

    def error(self, msg: str, ws: bool = True):
        """
        Send the given message to relevant targets. For example, logging and websocket.

        :param msg: message to log
        :param ws: True will send message on websockets as well
        :return:
        """
        self._logger.error(msg)
        self._send_ws_message(msg, MessageType.ERROR) if ws and self._logger.isEnabledFor(logging.ERROR) else None

    def debug(self, msg: str, ws: bool = True):
        """
        Send the given message to relevant targets. For example, logging and websocket.

        :param msg: message to log
        :param ws: True will send message on websockets as well
        :return:
        """
        self._logger.debug(msg)
        self._send_ws_message(msg, MessageType.DEBUG) if ws and self._logger.isEnabledFor(logging.DEBUG) else None

    def warning(self, msg: str, ws: bool = True):
        """
        Send the given message to relevant targets. For example, logging and websocket.

        :param msg: message to log
        :param ws: True will send message on websockets as well
        :return:
        """
        self._logger.warning(msg)
        self._send_ws_message(msg, MessageType.WARN) if ws and self._logger.isEnabledFor(logging.WARNING) else None

    def _send_ws_message(self, message: str, msg_type: MessageType = MessageType.INFO):
        """
        Just a wrapper around the websocket message sending functionality.

        :param message: message string
        :param msg_type: type of message
        :return:
        """
        self._ws_ah.send_message(message, str(msg_type.name)) if self._enable_ws_comm and self._ws_ah else None

    # ---- Market Interaction and Information Methods ----
    async def _process_order_queue(self):
        """
        A task to send orders from the queue to the exchange server. On acceptance and rejection of orders the subclass
        is notified. The subclass must override order_accepted and order_rejected abstract methods.

        :return: Asyncio co-routine
        """

        def order_accepted(info):
            self._safely_call_method(functools.partial(self.order_accepted, Order(info['id'], info)))

        def order_rejected(info):
            self._safely_call_method(functools.partial(self.order_rejected, info, order))

        # TODO: Candidate for modularisation and code extraction
        while not self.stop:
            while not self._outgoing_order_queue.empty():
                try:
                    order = self._outgoing_order_queue.get_nowait()

                    self.debug(f"Order Queued: {self._outgoing_order_count}")
                    await Request("/orders", order_accepted, error_callback_func=order_rejected,
                                  request_method=RequestMethod.POST, data=order.encode()).perform()
                    self.debug(f"  Order Sent: {self._outgoing_order_count}")

                    self._outgoing_order_count[order.market] -= 1
                except Exception as e:
                    self.error(f"Error when sending order. {type(e).__name__}: {e}")
                    self.debug(traceback.format_exc())

            await asyncio.sleep(cons.MONITOR_ORDER_BOOK_DELAY)

    async def _process_incoming_messages(self):
        """
        A task to process incoming messages to the trading agent.
        These messages normally come from robot hosting web-interface

        :return: Asyncio co-routine
        """
        while not self.stop:
            while not self._incoming_message_queue.empty():
                # TODO: Redo this section. Message handling is ugly and with hardcoded values
                # TODO: Add parsing of incoming WS messages from FM
                self.debug(f"Read:InQ({self._incoming_message_queue.qsize()})")
                message = self._incoming_message_queue.get_nowait()

                if "source" in message.keys() and message["source"] == "robot":
                    pass
                elif "command" in message.keys() and message["command"] == "stop":
                    self.stop = True
                elif "source" in message.keys() and message["source"] == "user" and self.enable_user_communication:
                    self._safely_call_method(functools.partial(self.respond_to_user, message['message']))
                elif any(x in message for x in list(IncomingMessageType)):
                    self.debug(f"{FM_HOST} MSG: {message}")
                    for k, v in message.items():
                        m_type = k.name.lower()
                        func = getattr(self, f"_on_{m_type}", None)
                        data_signal = self._data_signals.get(m_type)

                        if func and callable(func): func(v)
                        if data_signal: data_signal.send(m_type)

                # Work on this and clean the output. It duplicates messages on web and here, via websockets
                if 'message' in message and 'source' in message and message['source'].lower() != 'robot':
                    self.inform("Received message: " + str(message["message"]), ws=False)
                # TODO Post custom commands to the server, define domain language
            await asyncio.sleep(cons.WS_MESSAGE_DELAY)

    def _get_marketplace_info(self):
        """
        Get details of the assigned marketplace.
        This method retrieves the markets under this marketplace and also fetches private traders (if any).

        :return:
        """
        marketplace_url = cons.MARKETPLACE_URL.replace("$id$", str(self._marketplace_id))

        def _handle_mp_info(content):
            # Note: This function is also used as error handler, which will simply raise an error when instantiating a
            #   Marketplace object, expectedly due to missing key.
            self.debug(f"Marketplace info received: {content}")
            Marketplace(content['id'], content)

        def _handle_markets_info(content):
            markets = content["_embedded"]["markets"]
            self.debug(f"Markets info received: {markets}")
            [Market(market['id'], market) for market in markets]  # Creates singleton objects of Markets

        def _handle_private_traders(content: List = None):
            return sorted(content)

        def _set_private_traders(mkt: Market, content: List = None):
            mkt.update_attr('private_traders', content)
            self.debug(f"Private traders set for {mkt} to {content}")

        async def _get_private_traders(mkt):
            # Take a safer approach and just set it to None so clients don't have to perform exception handling
            _pvt = None
            try:
                self.debug(f"Requesting private traders info for {mkt}")
                _pvt = await Request(mkt.url_private_traders, _handle_private_traders).perform()
                self.debug(f"Private traders info received for {mkt}")
            except (AttributeError, TypeError) as e:
                self.debug(f"Private traders unavailable in {mkt}")
            finally:
                _set_private_traders(mkt, _pvt)

        async def get_mp_info():
            try:
                self.debug('Fetching marketplace info')
                await Request(marketplace_url, _handle_mp_info, _handle_mp_info).perform()

                # Private trader info is part of a Marketplace
                self.debug('Fetching private traders info from marketplace, if available')
                _pvt_t = None
                try:
                    _pvt_t = await Request(Marketplace(self._marketplace_id).url_private_traders,
                                           _handle_private_traders).perform()
                    self.debug('Private traders fetched for marketplace')
                except AttributeError:
                    self.debug(f"Marketplace does not contain private markets")
                except Exception as e:
                    self.debug(f"{type(e).__name__}: {e}")
                finally:
                    [_set_private_traders(m, _pvt_t if m.private_market else None) for m in Market.list_all()]

            except KeyError:
                raise ValueError(f"Marketplace({self._marketplace_id}) does not exist on {FM_HOST}")
            except Exception as e:
                self.error(f"Error while fetching marketplace info: {type(e).__name__}: {e}. See log for details")
                self.debug(traceback.format_exc())
                raise ConnectionError(e)

        return hlp.run_or_schedule_coroutine(get_mp_info())

    def _on_session_update(self, session_json: dict):
        old_state = self.current_session.state if self.current_session else None

        with self._session_semaphore:
            self._current_session = Session(session_json["id"], session_json)
            self.inform(f"Session: {self._current_session}")

        if old_state != self.current_session.state:
            self.debug(f"Session state changed. Open? {self.current_session.is_open}")
            if self.current_session.is_open and old_state is SessionState.CLOSED:
                Order.clear_all()
            self._safely_call_method(functools.partial(self.received_session_info, self.current_session))
            self.debug(f"Session: {self.current_session}: Notification complete")

    def _on_session_list(self, sessions_json: list[dict]):
        for _session_json in sessions_json:
            try:
                self.debug(f"Session from List: {Session(_session_json['id'], _session_json)}")
            except (KeyError, ValueError):
                self.debug(f"Error creating session from list: {_session_json}")

    def _on_holding_update(self, holding_json: dict):
        try:
            self._holdings = Holding(holding_json)
        except (AttributeError, ValueError, KeyError):
            self.error("Error creating holding")
            self.debug(traceback.format_exc())
        else:
            self._safely_call_method(functools.partial(self.received_holdings, self._holdings))

    def _on_orders_update(self, order_json: dict):
        _orders = []  # TODO: Refactor
        for _order in order_json:
            try:
                _orders.append(Order(_order['id'], _order))
            except Exception as ex:
                self.error(f"{ex.__class__.__name__}: {ex}. "
                           f"Error parsing incoming order data. Check debug log for more info.")
                self.debug(traceback.format_exc())
        # if _orders:
        self._safely_call_method(functools.partial(self.received_orders, _orders))

    def _process_signal(self, signal_sender, **kwargs):
        """
        One-time consume the signal with the given name.
        """
        self._initial_data_status[signal_sender] = True
        self._data_signals[signal_sender].disconnect(self._process_signal)

        if all(self._initial_data_status.values()):
            self._safely_call_method(self._data_init_signal.send)

    def _setup_signal_handlers(self):
        # Connect signal handlers for initial data receipt
        for _signal in self._data_signals.values():
            _signal.connect(self._process_signal)

        def _data_init_signal_handler(_):
            self._safely_call_method(self.initial_data_received)
            for receiver in copy.copy(self._data_init_signal.receivers):
                self._data_init_signal.disconnect(receiver)

        self._data_init_signal.connect(_data_init_signal_handler, weak=False)

    # ---- AGENT INIT, START AND CONTROL METHODS ----
    def _initialise(self):
        self._loop = self._get_event_loop()
        self._set_asyncio_properties()
        self._outgoing_order_queue = asyncio.Queue()
        self._incoming_message_queue = asyncio.Queue()
        self._setup_signal_handlers()

        # self._logger.setLevel(logging.DEBUG)

        try:
            # Attempt login
            self.inform(f"Attempting to log into {FM_HOST} as {self._account}|{self._email}")
            self._login()

            # Setup AlgoHost WebSocket Client
            if self._enable_ws_comm:
                self.inform(f"Establishing realtime WebSocket connection to AlgoHost")
                self._ws_ah = AgentWebsocketClient(self._name, self._account, self._email, self._password,
                                                   self._marketplace_id, cons.WS_ADDRESS, cons.WS_PORT, cons.WS_PATH,
                                                   self._incoming_message_queue, ssl=cons.WS_SSL)
                self._ws_ah.setup()

            # Setup FM WebSocket Client
            self.inform(f"Establishing realtime WebSocket connection to {FM_HOST}")
            self._ws_fm = WebSocketClient(self._name, cons.FM_WS_ROOT, cons.FM_WS_PATH, self._marketplace_id,
                                          self._incoming_message_queue)
            self._ws_fm.setup()

            # Fetch the essential marketplace information
            self.inform(f"Requesting initial information for marketplace `{self._marketplace_id}`")
            self._get_marketplace_info()
            self._outgoing_order_count = {mkt: 0 for mkt in Market.list_all()}

        except (aiohttp_exceptions.ClientResponseError,):
            self.error(f"Authentication failed for {self._account}|{self._email} on {FM_HOST}")
            raise
        except (aiohttp_exceptions.ClientConnectorCertificateError,):
            self.error("SSL Certificate error while connecting to FM Servers. "
                       "Check Python™ certificate installation documentation in FM manual.")
            raise
        except (aiohttp_exceptions.ClientConnectionError, ConnectionError):
            self.error(f"Unable to log into {FM_HOST} Servers or establish WebSocket connections")
            raise
        except KeyboardInterrupt:
            self.error("User interrupt received during initialisation.")
        except Exception as e:
            self.error(f"Something went wrong. {e}")
            raise
        else:
            self._initialised = True
        finally:
            if self._initialised:
                # Inform the trading agent that initialization is complete.
                self.debug(f"Init:InQ({self._incoming_message_queue.qsize()})")
                self.inform("Initialisation complete. Received marketplace information.")
                self.inform(f"I am {self.my_info()}")
                self._safely_call_method(self.initialised)
                self._init_communication()

            else:
                self.debug(traceback.format_exc()) if any(sys.exc_info()) else None
                self.warning('Initialisation failed. Exiting!')
                logging.shutdown()
                exit(1)

    def _start(self):
        """
        Start the algorithm execution by running the essential tasks in a loop.
        Each co-routine is executed in a single asyncio loop.

        :return:
        """
        try:
            asyncio_tasks = []

            # schedule and user defined tasks
            for task in self._user_tasks:
                asyncio_tasks.append(task)

            # task for the order processor
            asyncio_tasks.append(self._process_order_queue())

            # tasks for the handling incoming messages
            asyncio_tasks.append(self._process_incoming_messages())

            # run the loop
            try:
                # return exceptions True to prevent error in one task from failing all other tasks
                self._loop.run_until_complete(asyncio.gather(*asyncio_tasks, return_exceptions=True))
            except (aiohttp_exceptions.ServerConnectionError, aiohttp_exceptions.ServerDisconnectedError):
                self.error("Cannot connect to server!")
            except asyncio.TimeoutError:
                self.error("The connection to server timed out and now I have to die!")

        except KeyboardInterrupt:
            self.error("Oops. Keyboard Interrupt received from user.")
        finally:
            self.inform('Shutting Down')
            self.stop_after_wait(2)
            logging.shutdown()
            self._loop.close()

    # ---- Agent and Market Properties ----
    @property
    def current_session(self) -> Session:
        with self._session_semaphore:
            return self._current_session

    @property
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: str):
        self._description = value

    @property
    def name(self) -> str:
        return str(self._name)

    @name.setter
    def name(self, value: str):
        self._name = value

    @property
    def stop(self) -> bool:
        return self._stop

    @stop.setter
    def stop(self, value: bool):
        if not self._stop:
            self.inform(f"I have been asked to stop! {hlp.C_OKBLUE}{hlp.C_BOLD}:-({hlp.C_ENDC}")
            self._stop = bool(value)
            if self._enable_ws_comm and self._ws_ah:
                self._ws_ah.stop = bool(value)
            self._ws_fm.stop = bool(value)

    @property
    def marketplace(self) -> Marketplace:
        """
        Current Marketplace object

        .. versionadded: 3.3.0
            Added new property to return the current Marketplace object

        :return: Return the current Marketplace object
        """
        return Marketplace(self._marketplace_id)

    @property
    def markets(self) -> Dict[int, Market]:
        return Market.all()

    @property
    def holdings(self) -> Holding:
        return self._holdings

    @property
    def log_file(self) -> str:
        return self._log_file

    @property
    def enable_user_communication(self):
        return self._enable_user_communication

    @enable_user_communication.setter
    def enable_user_communication(self, value: bool):
        self._enable_user_communication = value

    # ---- Methods for subclasses and objects for various external tasks and starting robots ----
    def run(self):
        """This is the main method that initialises and starts a trading agent. This method starts market interaction

        All subclassing agents must call this method to start their agent.
        """
        self.inform(f"Using {LIB_NAME} version: {LIB_VERSION}")
        self._initialise()
        self._safely_call_method(self.pre_start_tasks)
        self._start()

    def stop_after_wait(self, wait_time: float):
        """
        Stop the algorithm execution in a graceful manner.
        Each perpetual task should by default check for the stop variable.

        :param wait_time: time to wait (in seconds) before stopping
        :return:
        """

        assert wait_time > 0, "wait time for stopping must be greater than 0"

        # set the stop variable to be true
        async def _wait_stop():
            self.stop = True
            await asyncio.sleep(wait_time)

        hlp.run_or_schedule_coroutine(_wait_stop())

    def execute_periodically(self, func: callable, sleep_time: int):
        """
        Register a co-routine for the given function to be executed perpetually with a delay.

        :param func: The function to be executed.
        :param sleep_time: The time to wait before the next execution (at least 1 second)

        :return:
        """
        assert sleep_time >= 1
        self.execute_periodically_variably_conditionally(func, lambda: sleep_time, lambda: True)

    def execute_periodically_variably(self, func: callable, sleep_time_func: callable):
        """
        Register a co-routine for the given function to be executed perpetually with a delay.

        :param func: The function to be executed.
        :param sleep_time_func: A callable that returns time to wait before next execution (at least 1 second)

        :return:
        """
        self.execute_periodically_variably_conditionally(func, sleep_time_func, lambda: True)

    def execute_periodically_conditionally(self, func: callable, sleep_time: int, condition: callable):
        """
        Register a co-routine for the given function to be executed conditionally and perpetually with a delay

        :param func: The function to be executed.
        :param sleep_time: The time to wait before the next execution (at least 1 second)
        :param condition: A callable that returns whether this function should be executed

        :return:
        """
        assert sleep_time >= 1
        self.execute_periodically_variably_conditionally(func, lambda: sleep_time, condition)

    def execute_periodically_variably_conditionally(self, func: callable, sleep_time_func: callable,
                                                    condition: callable):
        """
        Register a co-routine for the given function to be executed conditionally and perpetually with a variable delay

        :param func: The function to be executed.

        :param sleep_time_func: A callable that returns time to wait before next execution (at least 1 second)

        :param condition: A callable that returns whether this function should be executed

        :return:
        """

        async def _execute():
            while not self.stop:
                self._safely_call_method(func) if condition() else None
                await asyncio.sleep(sleep_time_func() or 1)

        self._user_tasks.append(_execute())

    def send_message_to_user(self, message: str):
        self._send_ws_message(message, MessageType.COMM)

    def my_info(self) -> str:
        """
        Send the algorithm name and associated User info.

        :return: Algorithm name(User info)
        """
        return f"{self._name}({FMAuth().auth_user})"

    def print_thread_info(self):
        """
        Print the number of thread count and names of active threads.

        :return:
        """
        print(f"{self}:{threading.current_thread()}:{threading.active_count()}")
        for t in threading.enumerate():
            print(t.name)

    def is_session_active(self) -> bool:
        return self.current_session.is_open

    def should_continue(self) -> bool:
        return not self.stop

    def is_session_active_and_can_continue(self) -> bool:
        return self.is_session_active() and self.should_continue()

    def pending_outgoing_orders_count(self, market: Market) -> int:
        """
        Return the number of pending orders in the order queue for a given market.

        :param market: market for which pending orders are requested
        :return: Number of orders waiting to be sent
        """
        assert isinstance(market, Market)
        return self._outgoing_order_count[market]

    def send_order(self, order: Order):
        """
        Send an order to the exchange.

        :param order:
        """
        assert isinstance(order, Order)
        self._outgoing_order_queue.put_nowait(order)
        self._outgoing_order_count[order.market] += 1

    # ---- Abstract Methods for Subclasses to make concrete ---
    @abstractmethod
    def initialised(self):
        """
        Called after agent initialisation is complete

        :return:
        """
        self.error("Method `initialised` not implemented.")
        raise NotImplementedError

    #@abstractmethod
    def initial_data_received(self) -> None:
        pass

    @abstractmethod
    def order_accepted(self, order: Order):
        """
        Called when an submitted order is accepted.

        :param order: Order that was submitted to the server
        :return:
        """
        self.error("Method `order_accepted` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def order_rejected(self, info: dict, order: Order):
        """
        Called when a submitted order is rejected.

        :param info: Error information returned by the server
        :param order: Order that was submitted to the server
        :return:
        """
        self.error("Method `order_rejected` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_orders(self, orders: List[Order]):
        """
        This method is called when orders are received from FM

        :param orders: List of Orders received from FM via WS
        :return:
        """
        self.error("Method `received_orders` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_holdings(self, holdings: Holding):
        """
        Called when holdings information is received from the exchange.
        This method should be overridden by the implementing sub-class.

        :param holdings:
        :return:
        """
        self.error("Method `received_holdings` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_session_info(self, session: Session):
        """
        Called when marketplace information is received from the exchange.

        :param session:
        :return:
        """
        self.error("Method `received_session_info` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def pre_start_tasks(self):
        """
        The sub-classed trading agent should override this method to perform any task or schedule tasks
        before Agent starts interacting in the marketplace

        :return:
        """
        self.warning("Method `pre_start_tasks` not implemented. No pre-start tasks scheduled.")
        raise NotImplementedError

    # @abstractmethod
    def respond_to_user(self, message: str):
        """
        Called when marketplace information is received from the exchange.

        :param message: Incoming message from user
        :return:
        """
        self.error("User communication is enabled but method `respond_to_user` not implemented.")
        raise NotImplementedError
