from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum


class MessageType(Enum):
    """
    Message types for the messages that the trading algorithm will exchange with the web browser.
    The message types are for the algorithmic logic and not the python code.
    """
    ERROR = 1
    DEBUG = 2
    INFO = 3
    WARN = 4
    CUSTOM = 5
    USER = 6
    COMM = 7


class Message(object):
    """
    Class for abstract the message entity. 
    The messages will be exchanged between a web browser and the algorithm.
    """
    def __init__(self, source: str, content: str, msg_type: MessageType,
                 date: datetime = datetime.now(timezone.utc), name: str = None):
        """
        The message type is defined by the content, the type of the message, the date of creation, and an optional name.
        The name attribute is relevant only for custom messages.
        :param source: source of the message.
        :param msg_type: message type (one of MessageType enum).
        :param content: content of the message.
        :param date: date of message.
        :param name: optional name for custom message types.
        """
        self._source = source
        self._type = msg_type
        self._content = content
        self._date = date
        self._name = name

    @property
    def source(self) -> str:
        return self._source

    @source.setter
    def source(self, value: str):
        self._source = value

    @property
    def msg_type(self) -> MessageType:
        return self._type

    @msg_type.setter
    def msg_type(self, value: MessageType):
        assert value is MessageType
        self._type = value

    @property
    def content(self) -> str:
        return self._content

    @content.setter
    def content(self, value: str):
        self._content = value

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str):
        self._name = value
